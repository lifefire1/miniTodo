//package ru.geekbrains.todolist.service;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//import ru.geekbrains.todolist.persist.entity.DvaCh;
//import ru.geekbrains.todolist.persist.repo.DvachRepository;
//import ru.geekbrains.todolist.persist.repo.UserRepository;
//import ru.geekbrains.todolist.repr.DvachRepr;
//
//import javax.transaction.Transactional;
//import java.util.List;
//import java.util.Optional;
//
//import static ru.geekbrains.todolist.security.Utils.getCurrentUser;
//
//
//@Service
//@Transactional
//public class DvachService {
//
//    private final UserRepository userRepository;
//
//    private final DvachRepository dvachRepository;
//
//    @Autowired
//    public DvachService(UserRepository userRepository, DvachRepository dvachRepository) {
//        this.userRepository = userRepository;
//        this.dvachRepository = dvachRepository;
//    }
//
//    public Optional<DvachRepr> findById(Long id) {
//        return dvachRepository.findById(id).map(DvachRepr::new);
//    }
//
//    public List<DvachRepr> findDvach() {
//        return dvachRepository.findComments();
//    }
//
//    public void save(DvachRepr dvachRepr) {
//        getCurrentUser()
//                .flatMap(userRepository::getUserByUsername)
//                .ifPresent(user -> {
//                    DvaCh dvaCh = new DvaCh();
//                    dvaCh.setId(dvachRepr.getId());
//                    dvaCh.setText_comment(dvachRepr.getText_comment());
//                    dvaCh.setUser(user);
//                    dvachRepository.save(dvaCh);
//                });
//    }
//
//    public void delete(Long id) {
//        dvachRepository.findById(id)
//                .ifPresent(dvaCh -> dvachRepository.delete(dvaCh));
//    }
//}
