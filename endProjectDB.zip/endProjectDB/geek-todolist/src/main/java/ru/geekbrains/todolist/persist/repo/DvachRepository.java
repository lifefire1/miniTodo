//package ru.geekbrains.todolist.persist.repo;
//
//import org.springframework.data.jpa.repository.Query;
//import org.springframework.data.repository.CrudRepository;
//import org.springframework.data.repository.query.Param;
//import ru.geekbrains.todolist.persist.entity.DvaCh;
//import ru.geekbrains.todolist.repr.DvachRepr;
//import ru.geekbrains.todolist.repr.ToDoRepr;
//import java.util.List;
//
//public interface DvachRepository extends CrudRepository<DvaCh, Long> {
//
//    @Query("select new ru.geekbrains.todolist.repr.DvachRepr(t.id,t.text_comment, t.user.username) " +
//            "from DvaCh t ")
//    List<DvachRepr> findComments();
//}
