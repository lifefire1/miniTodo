//package ru.geekbrains.todolist.persist.entity;
//
//import javax.persistence.*;
//
//
//@Entity
//@Table(name = "dvaCh_comments")
//public class DvaCh {
//
//    @Id
//    @GeneratedValue(strategy = GenerationType.AUTO)
//    private Long id;
//
//    @Column
//    private String text_comment;
//
//    @Column
//    @ManyToOne
//    @JoinColumn(name = "user_id")
//    private User user;
//
//    public DvaCh() {
//    }
//
//    public Long getId() {
//        return id;
//    }
//
//    public void setId(Long id) {
//        this.id = id;
//    }
//
//    public String getText_comment() {
//        return text_comment;
//    }
//
//    public void setText_comment(String text_comment) {
//        this.text_comment = text_comment;
//    }
//
//    public User getUser() {
//        return user;
//    }
//
//    public void setUser(User user) {
//        this.user = user;
//    }
//}
