//package ru.geekbrains.todolist.repr;
//
//
//import ru.geekbrains.todolist.persist.entity.DvaCh;
//
//
//import javax.validation.constraints.NotEmpty;
//
//
//public class DvachRepr {
//    private Long id;
//
//    @NotEmpty
//    private String text_comment;
//
//    @NotEmpty
//    private String username;
//
//    public DvachRepr() {
//    }
//
//    public DvachRepr(Long id, @NotEmpty String text_comment, String username) {
//        this.id = id;
//        this.text_comment = text_comment;
//        this.username = username;
//    }
//
//    public DvachRepr(DvaCh dvaCh) {
//        this.id = dvaCh.getId();
//        this.text_comment = dvaCh.getText_comment();
//        this.username = dvaCh.getUser().getUsername();
//    }
//
//    public Long getId() {
//        return id;
//    }
//
//    public void setId(Long id) {
//        this.id = id;
//    }
//
//    public String getText_comment() {
//        return text_comment;
//    }
//
//    public void setText_comment(String text_comment) {
//        this.text_comment = text_comment;
//    }
//
//    public String getUsername() {
//        return username;
//    }
//
//    public void setUsername(String username) {
//        this.username = username;
//    }
//
//}
